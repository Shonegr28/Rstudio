#' Title
#'
#' @param fire
#'
#' @return
#' @export
#'
#' @examples
use_data<- function(n) {
  fire <- read.csv("FIREDAM.csv")

}
